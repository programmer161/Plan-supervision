package cn.edu.wmq_final_works.ui.dashboard

import androidx.lifecycle.ViewModel
import cn.edu.wmq_final_works.MyDatabaseHelper

class PlanHomeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
