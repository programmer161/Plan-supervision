package cn.edu.wmq_final_works.ui.test

import androidx.lifecycle.ViewModel

class BlankViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
