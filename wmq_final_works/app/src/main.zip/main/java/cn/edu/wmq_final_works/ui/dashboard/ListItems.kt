package cn.edu.wmq_final_works.ui.dashboard

data class ListItems(
    var id2: Int,
    var item: String,
    var time: String,
    var progress: String
)